a = int(input("숫자 입력 : "))
b = int(input("숫자 입력 : "))

print("두 수의 합 :",a+b)
print("두 수의 차 : %d"%(a-b))
total = a*b
print("두 수의 곱 : ",total)
print("두 수의 나눗셈 : %d"%(a//b))